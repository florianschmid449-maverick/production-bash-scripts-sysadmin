#!/usr/bin/env bash
# ==============================================================================
# Script Name : ip_calc_subnet_helper.sh
# Description : Pure-Bash IPv4 CIDR calculator and interactive subnetting designer.
#               Computes network, broadcast, wildcard, netmask, and host capacities
#               with visual binary bitmask representation and interactive prompts.
# Author      : Florian Schmid
# Contact     : FlorianSchmid449@gmail.com
# Version     : 2.0.0
# License     : MIT
# Requirements: bash (>= 4.4), coreutils
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'

# ANSI Color & Style Codes
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

CIDR_INPUT="192.168.1.100/24"
INTERACTIVE=false

usage() {
    cat <<EOF
Usage: $(basename "$0") [OPTIONS]

Calculates IPv4 subnet boundaries, bitmasks, and host ranges via pure Bash.

Options:
  -c, --cidr <ip/prefix>   IPv4 address with CIDR prefix (default: 192.168.1.100/24)
  -m, --menu               Interactive subnetting calculation wizard
  -h, --help               Show this help message and exit

Examples:
  $(basename "$0") -c 10.50.0.1/22
  $(basename "$0") --menu
EOF
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        -c|--cidr)
            CIDR_INPUT="$2"; shift 2 ;;
        -m|--menu)
            INTERACTIVE=true; shift ;;
        -h|--help)
            usage ;;
        *)
            echo -e "${RED}[ERROR]${NC} Unknown option: $1" >&2
            exit 2 ;;
    esac
done

int2ip() {
    local int=$1
    echo "$(( (int >> 24) & 255 )).$(( (int >> 16) & 255 )).$(( (int >> 8) & 255 )).$(( int & 255 ))"
}

int2bin() {
    local int=$1
    local bin=""
    for ((i=31; i>=0; i--)); do
        local bit=$(( (int >> i) & 1 ))
        bin="${bin}${bit}"
        if [[ $(( (32 - i) % 8 )) -eq 0 && $i -ne 0 ]]; then
            bin="${bin}."
        fi
    done
    echo "$bin"
}

calculate_subnet() {
    local input="$1"
    local ip="${input%/*}"
    local prefix="${input#*/}"

    if [[ ! "$prefix" =~ ^[0-9]+$ || "$prefix" -lt 0 || "$prefix" -gt 32 ]]; then
        echo -e "${RED}[ERROR] Invalid CIDR prefix: ${prefix}${NC}" >&2
        return 1
    fi

    # Parse IP into integer
    local i1 i2 i3 i4
    IFS=. read -r i1 i2 i3 i4 <<< "$ip"
    local ip_int=$(( (i1 << 24) + (i2 << 16) + (i3 << 8) + i4 ))

    # Calculate mask
    local mask_int=0
    if [[ "$prefix" -gt 0 ]]; then
        mask_int=$(( ((0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF) ))
    fi

    local net_int=$(( ip_int & mask_int ))
    local broadcast_int=$(( net_int | (~mask_int & 0xFFFFFFFF) ))
    local wildcard_int=$(( ~mask_int & 0xFFFFFFFF ))

    local net_ip
    net_ip=$(int2ip "$net_int")
    local netmask
    netmask=$(int2ip "$mask_int")
    local broadcast_ip
    broadcast_ip=$(int2ip "$broadcast_int")
    local wildcard_ip
    wildcard_ip=$(int2ip "$wildcard_int")

    local hosts first_host last_host
    if [[ "$prefix" -le 30 ]]; then
        hosts=$(( (1 << (32 - prefix)) - 2 ))
        first_host=$(int2ip $((net_int + 1)))
        last_host=$(int2ip $((broadcast_int - 1)))
    else
        hosts=$(( 1 << (32 - prefix) ))
        first_host="$net_ip"
        last_host="$broadcast_ip"
    fi

    echo -e "${CYAN}====================================================================${NC}"
    echo -e "${BOLD}${CYAN} Pure-Bash IPv4 CIDR Subnet Calculator - Florian Schmid${NC}"
    echo -e "${CYAN}====================================================================${NC}"
    printf "  %-22s : %s\n" "Input CIDR Address" "${BOLD}${input}${NC}"
    printf "  %-22s : %s\n" "Network Address" "${GREEN}${BOLD}${net_ip}${NC}"
    printf "  %-22s : %s\n" "Subnet Netmask" "${netmask} (/${prefix})"
    printf "  %-22s : %s\n" "Wildcard Mask" "${wildcard_ip}"
    printf "  %-22s : %s\n" "Broadcast Address" "${broadcast_ip}"
    printf "  %-22s : %s\n" "Usable Host Range" "${first_host} - ${last_host}"
    printf "  %-22s : %s\n" "Total Usable Capacity" "${YELLOW}${BOLD}${hosts} hosts${NC}"
    echo -e "────────────────────────────────────────────────────────────────────"
    echo -e "${DIM}Binary Bitmask Representation:${NC}"
    printf "  %-12s : %s\n" "IP Bits" "$(int2bin "$ip_int")"
    printf "  %-12s : %s\n" "Mask Bits" "$(int2bin "$mask_int")"
    echo -e "────────────────────────────────────────────────────────────────────\n"
}

if [[ "$INTERACTIVE" == true ]]; then
    while true; do
        clear
        echo -e "${CYAN}====================================================================${NC}"
        echo -e "${BOLD}${CYAN} Interactive Subnetting Wizard - Florian Schmid${NC}"
        echo -e "${CYAN}====================================================================${NC}"
        read -rp "Enter an IP address with prefix (e.g. 10.0.0.1/24) [or 'q' to quit]: " user_cidr
        [[ "$user_cidr" == "q" || "$user_cidr" == "quit" ]] && exit 0
        [[ -z "$user_cidr" ]] && continue
        calculate_subnet "$user_cidr" || true
        read -rp "Press Enter to calculate another subnet..." _
    done
else
    calculate_subnet "$CIDR_INPUT"
fi

exit 0
