#!/usr/bin/env bash
# ==============================================================================
# Script Name : quick_http_file_server.sh
# Description : Instantly spawns a temporary HTTP file server in the current
#               directory with port selection and access logging for file transfers.
# Author      : Florian Schmid
# Contact     : FlorianSchmid449@gmail.com
# Version     : 1.0.0
# License     : MIT
# Requirements: bash (>= 4.4), python3 or busybox
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'

# ANSI Color Codes
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

PORT=8000
BIND_DIR="."

usage() {
    cat <<EOF
Usage: $(basename "$0") [OPTIONS]

Spawns a temporary zero-dependency HTTP file server.

Options:
  -p, --port <port>   Port to listen on (default: 8000)
  -d, --dir <path>    Root directory to serve (default: current directory)
  -h, --help          Show this help message and exit

Example:
  $(basename "$0") -p 8888 -d /tmp/share
EOF
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        -p|--port)
            PORT="$2"; shift 2 ;;
        -d|--dir)
            BIND_DIR="$2"; shift 2 ;;
        -h|--help)
            usage ;;
        *)
            echo -e "${RED}[ERROR]${NC} Unknown option: $1" >&2
            exit 2 ;;
    esac
done

echo -e "${CYAN}====================================================================${NC}"
echo -e "${CYAN} Quick Temporary HTTP File Server - Florian Schmid${NC}"
echo -e "${CYAN}====================================================================${NC}"
echo -e "Serving directory '${BIND_DIR}' on port ${PORT}..."
echo -e "Press Ctrl+C to stop server.\n"

if command -v python3 &>/dev/null; then
    (cd "$BIND_DIR" && python3 -m http.server "$PORT")
elif command -v busybox &>/dev/null; then
    (cd "$BIND_DIR" && busybox httpd -f -p "$PORT")
else
    echo -e "${RED}[ERROR] Neither python3 nor busybox found to serve HTTP.${NC}" >&2
    exit 1
fi

exit 0
