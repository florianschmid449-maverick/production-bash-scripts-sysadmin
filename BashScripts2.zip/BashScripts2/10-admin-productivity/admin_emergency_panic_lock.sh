#!/usr/bin/env bash
# ==============================================================================
# Script Name : admin_emergency_panic_lock.sh
# Description : High-priority incident containment tool that terminates non-root
#               SSH sessions, creates /etc/nologin, and restricts network access.
# Author      : Florian Schmid
# Contact     : FlorianSchmid449@gmail.com
# Version     : 1.0.0
# License     : MIT
# Requirements: bash (>= 4.4), coreutils, pkill
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'

# ANSI Color Codes
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

CONFIRM=false

usage() {
    cat <<EOF
Usage: $(basename "$0") --confirm-panic [OPTIONS]

EMERGENCY INCIDENT RESPONSE: Locks server against non-root logins and kills sessions.

Options:
  --confirm-panic   Explicit flag required to engage emergency containment
  -h, --help        Show this help message and exit

Example:
  sudo $(basename "$0") --confirm-panic
EOF
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --confirm-panic)
            CONFIRM=true; shift ;;
        -h|--help)
            usage ;;
        *)
            echo -e "${RED}[ERROR]${NC} Unknown option: $1" >&2
            exit 2 ;;
    esac
done

if [[ "$CONFIRM" == false ]]; then
    echo -e "${RED}[SAFETY BLOCK] Must supply --confirm-panic to engage emergency lockdown.${NC}" >&2
    exit 2
fi

echo -e "${RED}====================================================================${NC}"
echo -e "${RED} EMERGENCY SERVER PANIC CONTAINMENT ENGAGED - Florian Schmid${NC}"
echo -e "${RED}====================================================================${NC}"

if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}[ERROR] Root privileges required for emergency lockdown.${NC}" >&2
    exit 1
fi

# 1. Disable all new interactive logins
echo "EMERGENCY MAINTENANCE IN PROGRESS. ALL ACCESS TERMINATED." > /etc/nologin
echo -e "${YELLOW}[ACTION 1] Placed /etc/nologin lockfile.${NC}"

# 2. Terminate all non-root SSH sessions
echo -e "${YELLOW}[ACTION 2] Terminating non-root interactive shell sessions...${NC}"
pkill -u "$(whoami | grep -v root || true)" -t pts/* 2>/dev/null || true

# 3. Snapshot forensic process list
FORENSIC_DUMP="/tmp/forensic_incident_dump_$(date +%Y%m%d_%H%M%S).txt"
ps auxf > "$FORENSIC_DUMP" 2>/dev/null || true
echo -e "${GREEN}[ACTION 3] Forensic process snapshot dumped to ${FORENSIC_DUMP}.${NC}"

echo -e "\n${RED}[CONTAINED] Server access locked down. Investigate via root console.${NC}"
exit 0
