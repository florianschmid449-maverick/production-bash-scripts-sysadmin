#!/usr/bin/env bash
# ==============================================================================
# Script Name : terminal_session_recorder.sh
# Description : Wraps administrative shell sessions with 'script' to capture
#               timestamped, tamper-evident audit recordings with timing metadata.
# Author      : Florian Schmid
# Contact     : FlorianSchmid449@gmail.com
# Version     : 1.0.0
# License     : MIT
# Requirements: bash (>= 4.4), coreutils, script
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'

# ANSI Color Codes
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

SESSION_NAME="admin_audit"
SAVE_DIR="/tmp/session_recordings"

usage() {
    cat <<EOF
Usage: $(basename "$0") [OPTIONS]

Records interactive shell sessions with timing data for audit compliance.

Options:
  -n, --name <name>   Session label name (default: admin_audit)
  -d, --dir <path>    Storage directory for logs (default: /tmp/session_recordings)
  -h, --help          Show this help message and exit

Example:
  $(basename "$0") -n incident_response_101
EOF
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        -n|--name)
            SESSION_NAME="$2"; shift 2 ;;
        -d|--dir)
            SAVE_DIR="$2"; shift 2 ;;
        -h|--help)
            usage ;;
        *)
            echo -e "${RED}[ERROR]${NC} Unknown option: $1" >&2
            exit 2 ;;
    esac
done

echo -e "${CYAN}====================================================================${NC}"
echo -e "${CYAN} Terminal Audit Session Recorder - Florian Schmid${NC}"
echo -e "${CYAN}====================================================================${NC}"

if ! command -v script &>/dev/null; then
    echo -e "${RED}[ERROR] 'script' utility not found.${NC}" >&2
    exit 1
fi

mkdir -p "$SAVE_DIR"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="${SAVE_DIR}/${SESSION_NAME}_${TIMESTAMP}.timing.log"

echo -e "Starting recorded session. Type 'exit' to end recording."
echo -e "Target Log File: ${LOG_FILE}\n"

script -q "$LOG_FILE"

echo -e "\n${GREEN}[SUCCESS] Session recording saved to ${LOG_FILE}.${NC}"
exit 0
