#!/usr/bin/env bash
# ==============================================================================
# Script Name : markdown_doc_indexer.sh
# Description : Recursively parses Markdown files, extracts heading tags (#, ##),
#               generates URL slug anchors, and creates a Table of Contents.
# Author      : Florian Schmid
# Contact     : FlorianSchmid449@gmail.com
# Version     : 1.0.0
# License     : MIT
# Requirements: bash (>= 4.4), coreutils, awk, tr
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'

# ANSI Color Codes
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

MD_FILE="README.md"

usage() {
    cat <<EOF
Usage: $(basename "$0") [OPTIONS]

Generates a markdown Table of Contents with valid anchors from headers.

Options:
  -f, --file <path>   Markdown document to parse (default: README.md)
  -h, --help          Show this help message and exit

Example:
  $(basename "$0") -f PLAN.md
EOF
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        -f|--file)
            MD_FILE="$2"; shift 2 ;;
        -h|--help)
            usage ;;
        *)
            echo -e "${RED}[ERROR]${NC} Unknown option: $1" >&2
            exit 2 ;;
    esac
done

if [[ ! -f "$MD_FILE" ]]; then
    echo -e "${RED}[ERROR] File '${MD_FILE}' not found.${NC}" >&2
    exit 1
fi

echo -e "${CYAN}====================================================================${NC}"
echo -e "${CYAN} Markdown Table of Contents Indexer - Florian Schmid${NC}"
echo -e "${CYAN}====================================================================${NC}"
echo -e "Generated Table of Contents for: ${MD_FILE}\n"

grep -E '^#{2,3} ' "$MD_FILE" | while read -r line; do
    level=$(echo "$line" | awk '{print length($1)}')
    title=$(echo "$line" | sed 's/^#* //')
    anchor=$(echo "$title" | tr '[:upper:]' '[:lower:]' | tr ' ' '-' | tr -cd '[:alnum:]-')

    if [[ "$level" -eq 2 ]]; then
        echo "- [${title}](#${anchor})"
    elif [[ "$level" -eq 3 ]]; then
        echo "  - [${title}](#${anchor})"
    fi
done

exit 0
