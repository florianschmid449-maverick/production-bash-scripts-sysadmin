# Fedora Windows Password Recovery & Windows Account Rescue Tool

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Fedora%20Live%20USB-informational.svg)](https://getfedora.org)
[![OS Compatibility](https://img.shields.io/badge/Windows-10%20%7C%2011-0078D6.svg)](https://microsoft.com)
[![Status](https://img.shields.io/badge/Read--Only-Safe%20Operation-brightgreen.svg)](#safe-operation)

A self-contained **Fedora Live USB Windows Recovery and Account Rescue Utility** engineered to scan storage drives, identify Windows 10 and Windows 11 installations, detect NTFS system partitions, audit BitLocker volume encryption, and assist users with legitimate account recovery and data salvage.

Designed specifically to run directly from a **Fedora Workstation Live environment** without installing software onto the Windows computer or altering disk structures.

---

## SEO & Project Metadata

* **Project Title:** Fedora Windows Password Recovery and Windows Account Rescue Tool
* **Author:** Florian Schmid ([FlorianSchmid449@gmail.com](mailto:FlorianSchmid449@gmail.com))
* **Primary Capabilities:** Non-destructive Windows disk scanning, BitLocker status detection, read-only NTFS exploration, Windows 10/11 system discovery, account recovery workflow guidance.
* **SEO Keywords:**  
  `Fedora Windows password recovery`, `Windows password reset from Linux`, `Fedora Live USB recovery tool`, `Windows 10 password recovery`, `Windows 11 account recovery`, `Linux Windows recovery utility`, `Windows NTFS partition scanner`, `Windows forgotten password help`, `Offline Windows account recovery`, `BitLocker recovery key detection`.

---

## Key Features

1. **Automatic Windows Detection:**
   Rapidly queries system block devices (`lsblk`, `blkid`) and inspects NTFS partitions to locate existing Windows installations.
2. **Drive & Filesystem Audit:**
   Identifies hard drives, NVMe SSDs, SATA drives, partition topologies, and filesystem labels.
3. **Safe Read-Only Operation:**
   Mounts candidate partitions strictly read-only (`mount -o ro`) to prevent corruption, file locking, or unintended modification of Windows filesystems.
4. **BitLocker Encryption Detection:**
   Identifies BitLocker and encrypted storage volumes, explaining recovery key prerequisites and pointing users to official recovery portals.
5. **Detailed Recovery Reporting:**
   Exports a structured, timestamped audit log (`windows-recovery-report-YYYYMMDD-HHMMSS.txt`) directly to the Fedora Live session or USB storage.
6. **Legitimate Account Rescue Guidance:**
   Provides step-by-step instructions for resetting Microsoft Account passwords online, recovering local accounts via security questions, and retrieving BitLocker keys.

---

## Interactive Terminal Interface

```
====================================================================
   FEDORA LIVE USB WINDOWS ACCOUNT RESCUE & DIAGNOSTIC SUITE
====================================================================
 Author: Florian Schmid <FlorianSchmid449@gmail.com> | v1.0.0
 Mode  : Read-Only Non-Destructive Drive Inspection
====================================================================

  [1] Scan all connected drives & storage topology
  [2] Deep-scan partitions for Windows 10/11 installations
  [3] Check partitions for BitLocker / volume encryption
  [4] Generate & export comprehensive rescue audit report
  [5] Official Windows account recovery instructions
  [6] Exit utility

Select an option [1-6]:
```

---

## Installation & Usage on Fedora Live

### Step 1: Boot into Fedora Live USB
1. Create a bootable Fedora Workstation Live USB drive using [Fedora Media Writer](https://getfedora.org) or Rufus.
2. Insert the USB into the target computer and boot into the Fedora Live environment.

### Step 2: Download or Clone the Script
Open a terminal in Fedora Live:

```bash
git clone https://github.com/FlorianSchmid/fedora-windows-recovery.git
cd fedora-windows-recovery
```

Alternatively, download `fedora-windows-recovery.sh` directly.

### Step 3: Grant Execution Permissions & Run
```bash
chmod +x fedora-windows-recovery.sh
sudo ./fedora-windows-recovery.sh
```

*(Note: Root privileges via `sudo` are required to inspect raw block devices and mount NTFS partitions).*

---

## Legitimate Account Recovery Workflow

When locked out of a Windows computer, this utility guides you through the official Microsoft resolution paths:

1. **Microsoft Account Reset (Cloud-Linked Users):**
   * If the account uses an `@outlook.com`, `@hotmail.com`, or Microsoft 365 login, visit:  
     👉 [https://account.live.com/password/reset](https://account.live.com/password/reset)
   * Verify your identity via SMS or secondary email to reset the password. Reconnect the PC to Wi-Fi on the lock screen to synchronize.

2. **BitLocker Drive Encryption:**
   * If the drive is encrypted with BitLocker, retrieve your 48-digit numerical recovery key from your Microsoft Account portal:  
     👉 [https://account.microsoft.com/devices/recoverykey](https://account.microsoft.com/devices/recoverykey)

3. **Pre-Reinstallation Data Salvage:**
   * If Windows requires a reset or reinstallation, you can mount your unencrypted NTFS partition in Fedora Live to safely copy critical documents, photos, and project files from `/Users/<YourUsername>/` onto an external USB drive before proceeding.

---

## Disclaimer & Authorized Use

> [!IMPORTANT]
> This tool is developed strictly for **legitimate system administration, computer rescue, and authorized account recovery**. It does **not** bypass security protocols, extract password hashes, or crack credentials. Always verify ownership and obtain explicit permission before servicing computer systems.

---

## License

Distributed under the MIT License. See [LICENSE](LICENSE) for full details.

**Author:** Florian Schmid  
**Email:** [FlorianSchmid449@gmail.com](mailto:FlorianSchmid449@gmail.com)
