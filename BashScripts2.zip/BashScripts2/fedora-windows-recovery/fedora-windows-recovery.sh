#!/usr/bin/env bash
# ==============================================================================
# Script Name : fedora-windows-recovery.sh
# Description : Fedora Live USB Windows Account Rescue, Disk Diagnostic, & 
#               Offline Recovery Suite. Features automatic Windows 10/11 detection,
#               read-only NTFS mount analysis, BitLocker encryption awareness,
#               user profile discovery, EFI boot validation, and report exporting.
# Author      : Florian Schmid
# Contact     : FlorianSchmid449@gmail.com
# Version     : 2.0.0
# License     : MIT
# Requirements: bash (>= 4.4), util-linux (lsblk, blkid, findmnt), coreutils
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'

# ANSI Color & Formatting Codes
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

APP_NAME="Fedora Windows Recovery Suite"
APP_VERSION="2.0.0"
REPORT_FILE="windows-recovery-report-$(date +%Y%m%d-%H%M%S).txt"

# Temporary mount tracker for bulletproof cleanup
ACTIVE_MOUNTS=()

cleanup() {
    for mnt in "${ACTIVE_MOUNTS[@]:-}"; do
        if [[ -n "$mnt" && -d "$mnt" ]]; then
            umount "$mnt" 2>/dev/null || true
            rmdir "$mnt" 2>/dev/null || true
        fi
    done
}
trap cleanup EXIT INT TERM

check_dependencies() {
    local missing=()
    for cmd in lsblk blkid findmnt awk grep sort uniq; do
        if ! command -v "$cmd" &>/dev/null; then
            missing+=("$cmd")
        fi
    done

    if [[ ${#missing[@]} -gt 0 ]]; then
        echo -e "${RED}[ERROR] Missing critical utilities: ${missing[*]}${NC}" >&2
        echo -e "${YELLOW}Install them via: sudo dnf install util-linux coreutils ntfs-3g${NC}" >&2
        exit 1
    fi
}

draw_header() {
    clear
    echo -e "${CYAN}╔════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║${BOLD}      FEDORA LIVE USB WINDOWS RECOVERY & ACCOUNT RESCUE SUITE          ${NC}${CYAN}║${NC}"
    echo -e "${CYAN}╠════════════════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${CYAN}║${NC} Author : Florian Schmid <FlorianSchmid449@gmail.com>                   ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC} Version: v${APP_VERSION} | Environment: Fedora Workstation Live                ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC} Mode   : ${GREEN}STRICT READ-ONLY (Non-Destructive Storage Inspection)${NC}        ${CYAN}║${NC}"
    echo -e "${CYAN}╚════════════════════════════════════════════════════════════════════════╝${NC}\n"
}

progress_bar() {
    local duration=${1:-1}
    local steps=20
    local step_sleep
    step_sleep=$(awk -v d="$duration" -v s="$steps" 'BEGIN { printf "%.3f", d / s }')

    echo -ne "  Progress: ["
    for ((i=1; i<=steps; i++)); do
        echo -ne "${GREEN}█${NC}"
        sleep "$step_sleep"
    done
    echo -e "] ${GREEN}Done!${NC}\n"
}

scan_connected_drives() {
    draw_header
    echo -e "${BOLD}${YELLOW}► [1/7] PHYSICAL STORAGE DRIVE & TOPOLOGY SCANNER${NC}\n"
    echo -e "Detecting all internal NVMe SSDs, SATA drives, and removable USB devices...\n"

    lsblk -o NAME,SIZE,TYPE,FSTYPE,LABEL,UUID,RO,MOUNTPOINTS

    echo ""
    echo -e "${CYAN}Drive Summary Statistics:${NC}"
    local total_disks
    total_disks=$(lsblk -dno TYPE | grep -c "disk" || echo 0)
    local total_parts
    total_parts=$(lsblk -dno TYPE | grep -c "part" || echo 0)
    echo -e "  • Total Physical Disks Detected    : ${GREEN}${total_disks}${NC}"
    echo -e "  • Total Storage Partitions Detected: ${GREEN}${total_parts}${NC}"

    echo ""
    read -rp "Press [Enter] to return to main menu..." _
}

detect_windows_installations() {
    draw_header
    echo -e "${BOLD}${YELLOW}► [2/7] DEEP-SCANNING PARTITIONS FOR WINDOWS 10 / 11${NC}\n"
    echo -e "Mounting candidate NTFS partitions in strict read-only mode to locate Windows roots...\n"

    local found_count=0

    # Initialize log entry
    {
        echo "===================================================================="
        echo " FEDORA WINDOWS ACCOUNT RESCUE AUDIT REPORT"
        echo " Timestamp: $(date)"
        echo " Hostname : $(hostname 2>/dev/null || echo 'Fedora-Live')"
        echo " Kernel   : $(uname -r)"
        echo "===================================================================="
        echo ""
    } >> "$REPORT_FILE"

    while read -r part; do
        [[ -z "$part" ]] && continue

        local fstype
        fstype=$(blkid -o value -s TYPE "$part" 2>/dev/null || true)

        if [[ "$fstype" == "ntfs" ]]; then
            echo -e "${CYAN}Auditing Partition:${NC} ${part} (Filesystem: NTFS)"

            local mountpoint
            mountpoint=$(mktemp -d)
            ACTIVE_MOUNTS+=("$mountpoint")

            # Mount strictly read-only
            if mount -o ro "$part" "$mountpoint" 2>/dev/null; then
                if [[ -d "$mountpoint/Windows" && -d "$mountpoint/Windows/System32" ]]; then
                    found_count=$((found_count + 1))
                    echo -e "  ${GREEN}✔ [FOUND WINDOWS INSTALLATION]${NC}"
                    echo -e "    Device Node    : ${part}"

                    # Estimate build from kernel metadata if readable
                    local build_info="Windows 10 / 11 (NT Kernel 10.0)"
                    if [[ -f "$mountpoint/Windows/System32/ntoskrnl.exe" ]]; then
                        local size_bytes
                        size_bytes=$(stat -c %s "$mountpoint/Windows/System32/ntoskrnl.exe" 2>/dev/null || echo 0)
                        echo -e "    Kernel File    : ntoskrnl.exe (${size_bytes} bytes)"
                    fi

                    # Discover User Profiles on Windows Drive (Names only, read-only)
                    local user_list=()
                    if [[ -d "$mountpoint/Users" ]]; then
                        while IFS= read -r udir; do
                            local uname
                            uname=$(basename "$udir")
                            if [[ ! "$uname" =~ ^(Public|Default|Default\ User|All\ Users)$ ]]; then
                                user_list+=("$uname")
                            fi
                        done < <(find "$mountpoint/Users" -mindepth 1 -maxdepth 1 -type d 2>/dev/null || true)
                    fi

                    echo -e "    Estimated OS   : ${build_info}"
                    if [[ ${#user_list[@]} -gt 0 ]]; then
                        echo -e "    User Accounts  : ${YELLOW}${user_list[*]}${NC}"
                    else
                        echo -e "    User Accounts  : None found or restricted"
                    fi

                    # Calculate Partition Space Free / Used
                    local df_stats
                    df_stats=$(df -h "$mountpoint" | tail -n 1)
                    local total_sz
                    total_sz=$(echo "$df_stats" | awk '{print $2}')
                    local used_sz
                    used_sz=$(echo "$df_stats" | awk '{print $3}')
                    local avail_sz
                    avail_sz=$(echo "$df_stats" | awk '{print $4}')
                    echo -e "    Storage Usage  : Total: ${total_sz} | Used: ${used_sz} | Available: ${avail_sz}\n"

                    # Record in report
                    {
                        echo "[WINDOWS INSTALLATION AUDIT]"
                        echo "Partition Device   : ${part}"
                        echo "Filesystem         : NTFS"
                        echo "Kernel State       : Verified ntoskrnl.exe present"
                        echo "Windows Users Found: ${user_list[*]:-None}"
                        echo "Storage Capacity   : ${total_sz} (Used: ${used_sz}, Free: ${avail_sz})"
                        echo "Scan Timestamp     : $(date)"
                        echo "--------------------------------------------------------------------"
                    } >> "$REPORT_FILE"
                else
                    echo -e "  ${DIM}• Not a Windows system partition (Data volume or recovery partition).${NC}\n"
                fi

                umount "$mountpoint" 2>/dev/null || true
            else
                echo -e "  ${RED}✖ [LOCKED] Could not mount ${part} read-only (Dirty bit or hibernation active).${NC}\n"
            fi
            rmdir "$mountpoint" 2>/dev/null || true
        fi
    done < <(lsblk -rpno NAME,TYPE | awk '$2=="part" {print $1}')

    echo -e "────────────────────────────────────────────────────────────────────"
    if [[ "$found_count" -gt 0 ]]; then
        echo -e "${GREEN}[SUCCESS] Detected ${found_count} valid Windows installation(s).${NC}"
        echo -e "Audit log appended: ${BOLD}${REPORT_FILE}${NC}"
    else
        echo -e "${YELLOW}[NOTICE] No unencrypted Windows roots detected on active NTFS partitions.${NC}"
        echo -e "If the drive is encrypted with BitLocker, run Option [3]."
    fi

    echo ""
    read -rp "Press [Enter] to return to main menu..." _
}

audit_bitlocker_encryption() {
    draw_header
    echo -e "${BOLD}${YELLOW}► [3/7] BITLOCKER & VOLUME ENCRYPTION AUDITOR${NC}\n"
    echo -e "Inspecting partition headers for BitLocker / TPM protective layers...\n"

    local bitlocker_detected=false

    printf "%-18s %-20s %-15s %-25s\n" "DEVICE NODE" "ENCRYPTION TYPE" "SIZE" "LABEL"
    printf "%-18s %-20s %-15s %-25s\n" "-----------" "---------------" "----" "-----"

    while read -r dev fstype size label; do
        [[ -z "$dev" ]] && continue

        if [[ "$fstype" =~ BitLocker || "$fstype" =~ crypto_LUKS ]]; then
            bitlocker_detected=true
            printf "%-18s %-20s %-15s %-25s\n" "$dev" "$fstype" "$size" "${label:-Unlabeled}"

            {
                echo "[ENCRYPTED PARTITION DETECTED]"
                echo "Device Node    : ${dev}"
                echo "Encryption Type: ${fstype}"
                echo "Size           : ${size}"
                echo "Label          : ${label:-Unlabeled}"
                echo "--------------------------------------------------------------------"
            } >> "$REPORT_FILE"
        fi
    done < <(lsblk -rpno NAME,FSTYPE,SIZE,LABEL)

    echo ""
    if [[ "$bitlocker_detected" == true ]]; then
        echo -e "${RED}⚠ [ALERT] BitLocker encryption was discovered on storage partitions!${NC}"
        echo -e "${YELLOW}Recovery Key Information:${NC}"
        echo -e "  To unlock BitLocker partitions, Windows requires a 48-digit numerical key."
        echo -e "  You can look up your key from any smartphone or browser at:"
        echo -e "  ${BOLD}${CYAN}https://account.microsoft.com/devices/recoverykey${NC}\n"
        echo -e "Fedora Dislocker Unlock Command (if needed):"
        echo -e "  ${DIM}sudo dnf install -y dislocker${NC}"
        echo -e "  ${DIM}sudo dislocker -V /dev/sdXn -p<YOUR-48-DIGIT-KEY> -- /mnt/bitlocker${NC}"
    else
        echo -e "${GREEN}✔ [OK] No BitLocker encrypted partitions found. Standard NTFS access available.${NC}"
    fi

    echo ""
    read -rp "Press [Enter] to return to main menu..." _
}

detect_efi_boot_partitions() {
    draw_header
    echo -e "${BOLD}${YELLOW}► [4/7] EFI SYSTEM PARTITION & BOOTLOADER AUDITOR${NC}\n"
    echo -e "Locating UEFI boot partitions (vfat/FAT32) to verify Windows Boot Manager...\n"

    local efi_count=0

    while read -r part fstype size label; do
        if [[ "$fstype" == "vfat" ]]; then
            local mountpoint
            mountpoint=$(mktemp -d)
            ACTIVE_MOUNTS+=("$mountpoint")

            if mount -o ro "$part" "$mountpoint" 2>/dev/null; then
                if [[ -d "$mountpoint/EFI/Microsoft/Boot" || -f "$mountpoint/EFI/Microsoft/Boot/bootmgfw.efi" ]]; then
                    efi_count=$((efi_count + 1))
                    echo -e "  ${GREEN}✔ [FOUND WINDOWS UEFI BOOTLOADER]${NC} on ${part}"
                    echo -e "    File : /EFI/Microsoft/Boot/bootmgfw.efi"
                    echo -e "    Size : ${size} | Label: ${label:-None}\n"

                    {
                        echo "[EFI SYSTEM PARTITION]"
                        echo "Device : ${part}"
                        echo "Status : Valid Windows Boot Manager (bootmgfw.efi) verified"
                        echo "--------------------------------------------------------------------"
                    } >> "$REPORT_FILE"
                fi
                umount "$mountpoint" 2>/dev/null || true
            fi
            rmdir "$mountpoint" 2>/dev/null || true
        fi
    done < <(lsblk -rpno NAME,FSTYPE,SIZE,LABEL)

    if [[ "$efi_count" -eq 0 ]]; then
        echo -e "${YELLOW}[NOTICE] No UEFI Windows Boot Manager partitions found (System may use legacy MBR).${NC}"
    fi

    echo ""
    read -rp "Press [Enter] to return to main menu..." _
}

export_comprehensive_report() {
    draw_header
    echo -e "${BOLD}${YELLOW}► [5/7] COMPILING & EXPORTING RESCUE REPORT${NC}\n"

    {
        echo "===================================================================="
        echo " COMPLETE STORAGE DEVICE TOPOLOGY"
        echo "===================================================================="
        lsblk -o NAME,SIZE,TYPE,FSTYPE,LABEL,UUID,MOUNTPOINTS
        echo ""
        echo "===================================================================="
        echo " LIVE ENVIRONMENT DIAGNOSTIC ENVIRONMENT"
        echo "===================================================================="
        uname -a
        free -h
        uptime
        echo "===================================================================="
    } >> "$REPORT_FILE"

    echo -e "${GREEN}✔ Audit report successfully created:${NC}"
    echo -e "  File Path: ${BOLD}$(pwd)/${REPORT_FILE}${NC}"
    echo -e "  File Size: $(stat -c %s "$REPORT_FILE") bytes\n"

    echo -e "${CYAN}Recent Report Excerpt:${NC}"
    head -n 15 "$REPORT_FILE" | sed 's/^/  /'

    echo ""
    read -rp "Press [Enter] to return to main menu..." _
}

display_recovery_playbook() {
    draw_header
    echo -e "${CYAN}════════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD} OFFICIAL WINDOWS ACCOUNT RECOVERY & RESCUE PLAYBOOK${NC}"
    echo -e "${CYAN}════════════════════════════════════════════════════════════════════════${NC}\n"

    echo -e "${BOLD}${YELLOW}1. Microsoft Account Password Reset (Fastest & Standard):${NC}"
    echo -e "   If your Windows login email is linked to Outlook, Live, or Hotmail:"
    echo -e "   • Open a browser and visit: ${GREEN}https://account.live.com/password/reset${NC}"
    echo -e "   • Authenticate using your 2FA authenticator app, phone SMS, or backup email."
    echo -e "   • Once reset, connect your Windows computer to Wi-Fi on the lock screen."
    echo -e "   • Enter your new password to automatically sync credentials.\n"

    echo -e "${BOLD}${YELLOW}2. BitLocker 48-Digit Key Recovery:${NC}"
    echo -e "   If Windows boot stops at the blue BitLocker recovery prompt:"
    echo -e "   • Visit: ${GREEN}https://account.microsoft.com/devices/recoverykey${NC}"
    echo -e "   • Log in with any Microsoft account associated with the device."
    echo -e "   • Locate the Key ID matching the prompt on your screen and enter the numbers.\n"

    echo -e "${BOLD}${YELLOW}3. Local Account Password Reset (Security Questions):${NC}"
    echo -e "   • On the Windows 10/11 lock screen, click ${CYAN}'Reset password'${NC} below the box."
    echo -e "   • Answer the 3 security questions configured during initial computer setup."
    echo -e "   • Choose a new local password immediately.\n"

    echo -e "${BOLD}${YELLOW}4. Pre-Reinstallation File Rescue (Safeguard Personal Data):${NC}"
    echo -e "   • If Windows is unbootable or corrupted, keep your Fedora Live session open."
    echo -e "   • Mount the NTFS drive read-only in the Fedora file manager."
    echo -e "   • Safely copy your files from ${CYAN}/Windows/Users/<YourUsername>/Documents${NC}"
    echo -e "     onto an external flash drive before reinstalling the operating system."

    echo ""
    read -rp "Press [Enter] to return to main menu..." _
}

interactive_main_menu() {
    while true; do
        draw_header
        echo -e "  ${BOLD}[1]${NC} Scan all physical drives & partition topology"
        echo -e "  ${BOLD}[2]${NC} Deep-scan for Windows 10/11 installations & user profiles"
        echo -e "  ${BOLD}[3]${NC} Audit storage partitions for BitLocker encryption"
        echo -e "  ${BOLD}[4]${NC} Detect EFI System Partitions & Windows Boot Manager"
        echo -e "  ${BOLD}[5]${NC} Generate & export full diagnostic rescue report"
        echo -e "  ${BOLD}[6]${NC} View official Windows account recovery playbook"
        echo -e "  ${BOLD}[7]${NC} Exit utility"
        echo ""

        read -rp "Select an option [1-7]: " choice

        case "$choice" in
            1) scan_connected_drives ;;
            2) detect_windows_installations ;;
            3) audit_bitlocker_encryption ;;
            4) detect_efi_boot_partitions ;;
            5) export_comprehensive_report ;;
            6) display_recovery_playbook ;;
            7)
                echo -e "\n${GREEN}Exiting. Thank you for using the Fedora Windows Recovery Suite.${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Invalid selection. Please choose an option from 1 to 7.${NC}"
                sleep 1
                ;;
        esac
    done
}

# Entry point execution
check_dependencies
interactive_main_menu
