# Changelog

All notable changes to the **Fedora Windows Password Recovery & Account Rescue Tool** will be documented in this file.

## [1.0.0] - 2026-11-07

### Added
- Interactive terminal dashboard with color-coded status alerts.
- Automated block device and storage partition topology scanner.
- Non-destructive, read-only (`mount -o ro`) NTFS partition detection.
- Windows system directory and `ntoskrnl.exe` verification.
- BitLocker volume encryption audit and guidance.
- Comprehensive diagnostic rescue report generation (`windows-recovery-report-*.txt`).
- Step-by-step account recovery guidance for Microsoft Accounts, local accounts, and BitLocker keys.
- SEO-optimized README documentation, metadata, and MIT License.
